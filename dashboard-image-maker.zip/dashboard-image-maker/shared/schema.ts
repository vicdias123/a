import { pgTable, text, serial, integer, boolean, uuid, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const clients = pgTable("clients", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  document_number: text("document_number"),
  client_type: text("client_type"),
  address: text("address"),
  notes: text("notes"),
  status: text("status").default("active"),
  created_by: uuid("created_by"),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
});

export const cases = pgTable("cases", {
  id: uuid("id").primaryKey().defaultRandom(),
  case_number: text("case_number").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  client_id: uuid("client_id").references(() => clients.id),
  responsible_lawyer_id: uuid("responsible_lawyer_id"),
  case_type: text("case_type").notNull(),
  status: text("status").default("active"),
  priority: text("priority").default("medium"),
  court: text("court"),
  case_value: decimal("case_value", { precision: 15, scale: 2 }),
  start_date: timestamp("start_date"),
  expected_end_date: timestamp("expected_end_date"),
  actual_end_date: timestamp("actual_end_date"),
  created_by: uuid("created_by"),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  appointment_type: text("appointment_type").notNull(),
  start_time: timestamp("start_time").notNull(),
  end_time: timestamp("end_time").notNull(),
  location: text("location"),
  case_id: uuid("case_id").references(() => cases.id),
  client_id: uuid("client_id").references(() => clients.id),
  assigned_to: text("assigned_to"),
  is_confirmed: boolean("is_confirmed").default(false),
  reminder_sent: boolean("reminder_sent").default(false),
  created_by: text("created_by"),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export const insertCaseSchema = createInsertSchema(cases).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Case = typeof cases.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;
