import { 
  users, appointments, clients, cases,
  type User, type InsertUser,
  type Appointment, type InsertAppointment,
  type Client, type InsertClient,
  type Case, type InsertCase
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Appointments
  getAppointments(startDate?: Date, endDate?: Date, userId?: string): Promise<Appointment[]>;
  getAppointmentById(id: string): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment>;
  deleteAppointment(id: string): Promise<void>;
  
  // Clients
  getClients(): Promise<Client[]>;
  getClientById(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, client: Partial<InsertClient>): Promise<Client>;
  deleteClient(id: string): Promise<void>;
  
  // Cases
  getCases(): Promise<Case[]>;
  getCaseById(id: string): Promise<Case | undefined>;
  createCase(caseData: InsertCase): Promise<Case>;
  updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case>;
  deleteCase(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Appointments
  async getAppointments(startDate?: Date, endDate?: Date, userId?: string): Promise<Appointment[]> {
    const conditions = [];
    
    if (startDate) {
      conditions.push(gte(appointments.start_time, startDate));
    }
    
    if (endDate) {
      conditions.push(lte(appointments.start_time, endDate));
    }
    
    if (userId) {
      conditions.push(eq(appointments.assigned_to, userId));
    }
    
    if (conditions.length > 0) {
      return await db.select().from(appointments).where(and(...conditions));
    }
    
    return await db.select().from(appointments);
  }

  async getAppointmentById(id: string): Promise<Appointment | undefined> {
    const result = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
    return result[0];
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const result = await db.insert(appointments).values(appointment).returning();
    return result[0];
  }

  async updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment> {
    const result = await db
      .update(appointments)
      .set({ ...appointment, updated_at: new Date() })
      .where(eq(appointments.id, id))
      .returning();
    
    if (result.length === 0) {
      throw new Error('Appointment not found');
    }
    
    return result[0];
  }

  async deleteAppointment(id: string): Promise<void> {
    await db.delete(appointments).where(eq(appointments.id, id));
  }

  // Clients
  async getClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getClientById(id: string): Promise<Client | undefined> {
    const result = await db.select().from(clients).where(eq(clients.id, id)).limit(1);
    return result[0];
  }

  async createClient(client: InsertClient): Promise<Client> {
    const result = await db.insert(clients).values(client).returning();
    return result[0];
  }

  async updateClient(id: string, client: Partial<InsertClient>): Promise<Client> {
    const result = await db
      .update(clients)
      .set({ ...client, updated_at: new Date() })
      .where(eq(clients.id, id))
      .returning();
    
    if (result.length === 0) {
      throw new Error('Client not found');
    }
    
    return result[0];
  }

  async deleteClient(id: string): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  // Cases
  async getCases(): Promise<Case[]> {
    return await db.select().from(cases);
  }

  async getCaseById(id: string): Promise<Case | undefined> {
    const result = await db.select().from(cases).where(eq(cases.id, id)).limit(1);
    return result[0];
  }

  async createCase(caseData: InsertCase): Promise<Case> {
    const result = await db.insert(cases).values(caseData).returning();
    return result[0];
  }

  async updateCase(id: string, caseData: Partial<InsertCase>): Promise<Case> {
    const result = await db
      .update(cases)
      .set({ ...caseData, updated_at: new Date() })
      .where(eq(cases.id, id))
      .returning();
    
    if (result.length === 0) {
      throw new Error('Case not found');
    }
    
    return result[0];
  }

  async deleteCase(id: string): Promise<void> {
    await db.delete(cases).where(eq(cases.id, id));
  }
}

export const storage = new DatabaseStorage();
