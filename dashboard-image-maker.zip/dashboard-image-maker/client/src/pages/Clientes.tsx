import { useState, useEffect } from "react";
import { Search, SlidersHorizontal, Plus, Phone, Mail, MapPin, Trash2, Edit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/Sidebar";
import TopNavigation from "@/components/TopNavigation";
import { getClients, deleteClient, type Client } from "@/services/clientService";

const Clientes = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      setLoading(true);
      const data = await getClients();
      setClients(data);
    } catch (error) {
      console.error('Erro ao carregar clientes:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os clientes.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClient = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este cliente?')) {
      return;
    }

    try {
      await deleteClient(id);
      setClients(clients.filter(client => client.id !== id));
      toast({
        title: "Sucesso",
        description: "Cliente excluído com sucesso.",
      });
    } catch (error) {
      console.error('Erro ao excluir cliente:', error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o cliente.",
        variant: "destructive"
      });
    }
  };

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.document_number?.includes(searchTerm)
  );

  const getClientType = (type: string | null) => {
    return type === 'company' ? 'Pessoa Jurídica' : 'Pessoa Física';
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "inactive": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-accent/30 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <TopNavigation />
        
        <main className="flex-1 p-6">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-semibold text-foreground">Gestão de Clientes</h1>
                <p className="text-sm text-muted-foreground">Gerencie todos os clientes do escritório</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
                  <Input 
                    className="pl-10 w-64" 
                    placeholder="Buscar clientes..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <Button variant="outline" size="sm">
                  <SlidersHorizontal size={16} className="mr-2" />
                  Filtros
                </Button>
                
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus size={16} className="mr-2" />
                  Novo Cliente
                </Button>
              </div>
            </div>

            {/* Cards de Métricas */}
            <div className="grid grid-cols-4 gap-6 mb-8">
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl">👥</span>
                  <span className="text-sm text-green-600 font-medium">100%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{clients.length}</h3>
                <p className="text-sm text-muted-foreground">Total de Clientes</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl">✅</span>
                  <span className="text-sm text-green-600 font-medium">100%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{clients.filter(c => c.status === 'active').length}</h3>
                <p className="text-sm text-muted-foreground">Clientes Ativos</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl">🏢</span>
                  <span className="text-sm text-blue-600 font-medium">{Math.round((clients.filter(c => c.client_type === 'company').length / Math.max(clients.length, 1)) * 100)}%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{clients.filter(c => c.client_type === 'company').length}</h3>
                <p className="text-sm text-muted-foreground">Pessoas Jurídicas</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl">👤</span>
                  <span className="text-sm text-green-600 font-medium">{Math.round((clients.filter(c => c.client_type === 'individual').length / Math.max(clients.length, 1)) * 100)}%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{clients.filter(c => c.client_type === 'individual').length}</h3>
                <p className="text-sm text-muted-foreground">Pessoas Físicas</p>
              </div>
            </div>

            {/* Lista de Clientes */}
            <div className="bg-card rounded-2xl border">
              <div className="p-6 border-b">
                <h2 className="text-lg font-semibold text-foreground">Lista de Clientes</h2>
                <p className="text-sm text-muted-foreground mt-1">Gerencie informações dos clientes</p>
              </div>
              
              {loading ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">Carregando clientes...</p>
                </div>
              ) : filteredClients.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">Nenhum cliente encontrado.</p>
                </div>
              ) : (
                <div className="divide-y">
                  {filteredClients.map((client) => (
                    <div key={client.id} className="p-6 hover:bg-accent/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="bg-primary/10 text-primary font-medium">
                              {getInitials(client.name)}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <h3 className="font-semibold text-foreground">{client.name}</h3>
                              <Badge className={getStatusColor(client.status)}>
                                {client.status === 'active' ? 'Ativo' : 'Inativo'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{getClientType(client.client_type)} • {client.document_number}</p>
                            <div className="flex items-center gap-4 mt-2">
                              {client.email && (
                                <div className="flex items-center gap-1">
                                  <Mail className="w-3 h-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">{client.email}</span>
                                </div>
                              )}
                              {client.phone && (
                                <div className="flex items-center gap-1">
                                  <Phone className="w-3 h-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">{client.phone}</span>
                                </div>
                              )}
                              {client.address && (
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-3 h-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">{client.address}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-6">
                          <div className="text-center">
                            <p className="text-sm font-medium text-foreground">{client.created_at.toLocaleDateString('pt-BR')}</p>
                            <p className="text-xs text-muted-foreground">Data de Cadastro</p>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <Edit size={14} className="mr-1" />
                              Editar
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleDeleteClient(client.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Clientes;