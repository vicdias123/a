import { useState, useEffect } from "react";
import { Search, SlidersHorizontal, Plus, Scale, Calendar, Clock, AlertTriangle, Trash2, Edit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/Sidebar";
import TopNavigation from "@/components/TopNavigation";
import { getCases, deleteCase, type Case } from "@/services/caseService";
import { getClients, type Client } from "@/services/clientService";

const Processos = () => {
  const [cases, setCases] = useState<Case[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [casesData, clientsData] = await Promise.all([
        getCases(),
        getClients()
      ]);
      setCases(casesData);
      setClients(clientsData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCase = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este processo?')) {
      return;
    }

    try {
      await deleteCase(id);
      setCases(cases.filter(c => c.id !== id));
      toast({
        title: "Sucesso",
        description: "Processo excluído com sucesso.",
      });
    } catch (error) {
      console.error('Erro ao excluir processo:', error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o processo.",
        variant: "destructive"
      });
    }
  };

  const filteredCases = cases.filter(caseItem =>
    caseItem.case_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    caseItem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    caseItem.case_type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-blue-100 text-blue-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "closed": return "bg-green-100 text-green-800";
      case "suspended": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getClientName = (clientId: string | null) => {
    if (!clientId) return "Cliente não definido";
    const client = clients.find(c => c.id === clientId);
    return client?.name || "Cliente não encontrado";
  };

  const getInitials = (text: string) => {
    return text.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const formatCurrency = (value: string | null) => {
    if (!value) return "Não informado";
    const numValue = parseFloat(value);
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(numValue);
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "Não definido";
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <div className="min-h-screen bg-accent/30 flex">
      <Sidebar />
      
      <div className="flex-1 flex flex-col">
        <TopNavigation />
        
        <main className="flex-1 p-6">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-semibold text-foreground">Gestão de Processos</h1>
                <p className="text-sm text-muted-foreground">Acompanhe todos os processos do escritório</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
                  <Input 
                    className="pl-10 w-64" 
                    placeholder="Buscar por número, cliente..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <Button variant="outline" size="sm">
                  <SlidersHorizontal size={16} className="mr-2" />
                  Filtros
                </Button>
                
                <Button className="bg-primary hover:bg-primary/90">
                  <Plus size={16} className="mr-2" />
                  Novo Processo
                </Button>
              </div>
            </div>

            {/* Cards de Métricas */}
            <div className="grid grid-cols-4 gap-6 mb-8">
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <Scale className="text-2xl text-primary" size={24} />
                  <span className="text-sm text-green-600 font-medium">100%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{cases.length}</h3>
                <p className="text-sm text-muted-foreground">Total de Processos</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <Clock className="text-2xl text-blue-600" size={24} />
                  <span className="text-sm text-blue-600 font-medium">{Math.round((cases.filter(c => c.status === 'active').length / Math.max(cases.length, 1)) * 100)}%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{cases.filter(c => c.status === 'active').length}</h3>
                <p className="text-sm text-muted-foreground">Em Andamento</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <AlertTriangle className="text-2xl text-red-600" size={24} />
                  <span className="text-sm text-red-600 font-medium">{Math.round((cases.filter(c => c.priority === 'high').length / Math.max(cases.length, 1)) * 100)}%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{cases.filter(c => c.priority === 'high').length}</h3>
                <p className="text-sm text-muted-foreground">Alta Prioridade</p>
              </div>
              
              <div className="bg-card p-6 rounded-2xl border">
                <div className="flex items-center justify-between mb-4">
                  <Calendar className="text-2xl text-green-600" size={24} />
                  <span className="text-sm text-green-600 font-medium">{Math.round((cases.filter(c => c.status === 'closed').length / Math.max(cases.length, 1)) * 100)}%</span>
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-1">{cases.filter(c => c.status === 'closed').length}</h3>
                <p className="text-sm text-muted-foreground">Finalizados</p>
              </div>
            </div>

            {/* Lista de Processos */}
            <div className="bg-card rounded-2xl border">
              <div className="p-6 border-b">
                <h2 className="text-lg font-semibold text-foreground">Lista de Processos</h2>
                <p className="text-sm text-muted-foreground mt-1">Gerencie todos os processos jurídicos</p>
              </div>
              
              {loading ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">Carregando processos...</p>
                </div>
              ) : filteredCases.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">Nenhum processo encontrado.</p>
                </div>
              ) : (
                <div className="divide-y">
                  {filteredCases.map((caseItem) => (
                    <div key={caseItem.id} className="p-6 hover:bg-accent/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="bg-primary/10 text-primary font-medium">
                              {getInitials(caseItem.case_type)}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="font-semibold text-foreground">{caseItem.title}</h3>
                              <Badge className={getStatusColor(caseItem.status)}>
                                {caseItem.status === 'active' ? 'Em Andamento' :
                                 caseItem.status === 'pending' ? 'Pendente' :
                                 caseItem.status === 'closed' ? 'Finalizado' : 'Suspenso'}
                              </Badge>
                              <Badge className={getPriorityColor(caseItem.priority)}>
                                {caseItem.priority === 'high' ? 'Alta' :
                                 caseItem.priority === 'medium' ? 'Média' : 'Baixa'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{caseItem.case_number}</p>
                            <div className="flex items-center gap-6 text-sm text-muted-foreground">
                              <span><strong>Cliente:</strong> {getClientName(caseItem.client_id)}</span>
                              <span><strong>Área:</strong> {caseItem.case_type}</span>
                              <span><strong>Tribunal:</strong> {caseItem.court || "Não definido"}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-sm font-medium text-foreground">{formatCurrency(caseItem.case_value)}</p>
                            <p className="text-xs text-muted-foreground">Valor da Causa</p>
                          </div>
                          
                          <div className="text-right">
                            <p className="text-sm font-medium text-foreground">{formatDate(caseItem.start_date)}</p>
                            <p className="text-xs text-muted-foreground">Data de Início</p>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <Edit size={14} className="mr-1" />
                              Editar
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleDeleteCase(caseItem.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Processos;