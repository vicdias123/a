
import { Appointment, AppointmentFormData } from '@/types/appointment';

export const getAppointments = async (
  startDate?: Date,
  endDate?: Date,
  userId?: string
): Promise<Appointment[]> => {
  try {
    const params = new URLSearchParams();
    
    if (startDate) {
      params.append('startDate', startDate.toISOString());
    }
    
    if (endDate) {
      params.append('endDate', endDate.toISOString());
    }
    
    if (userId) {
      params.append('userId', userId);
    }
    
    const response = await fetch(`/api/appointments?${params.toString()}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const appointments = await response.json();
    return appointments.map((appointment: any) => ({
      ...appointment,
      start_time: new Date(appointment.start_time),
      end_time: new Date(appointment.end_time),
      created_at: new Date(appointment.created_at),
      updated_at: new Date(appointment.updated_at),
    }));
  } catch (error) {
    console.error('Erro ao buscar compromissos:', error);
    throw error;
  }
};

export const getAppointmentsByDate = async (
  date: Date,
): Promise<Appointment[]> => {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return getAppointments(startOfDay, endOfDay);
};

export const getTodayAppointments = async (): Promise<Appointment[]> => {
  return getAppointmentsByDate(new Date());
};

export const getWeekAppointments = async (): Promise<Appointment[]> => {
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  endOfWeek.setHours(23, 59, 59, 999);
  
  return getAppointments(startOfWeek, endOfWeek);
};

export const createAppointment = async (data: AppointmentFormData): Promise<Appointment> => {
  try {
    const appointmentData = {
      title: data.title,
      description: data.description,
      appointment_type: data.appointment_type,
      start_time: data.start_time,
      end_time: data.end_time,
      location: data.location,
      case_id: data.case_id || null,
      client_id: data.client_id || null,
      assigned_to: data.assigned_to,
      is_confirmed: data.is_confirmed,
      reminder_sent: false,
      created_by: 'current-user'
    };

    const response = await fetch('/api/appointments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(appointmentData),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const appointment = await response.json();
    return {
      ...appointment,
      start_time: new Date(appointment.start_time),
      end_time: new Date(appointment.end_time),
      created_at: new Date(appointment.created_at),
      updated_at: new Date(appointment.updated_at),
    };
  } catch (error) {
    console.error('Erro ao criar compromisso:', error);
    throw error;
  }
};

export const updateAppointment = async (id: string, data: Partial<AppointmentFormData>): Promise<Appointment> => {
  try {
    const appointmentData = {
      ...data,
      start_time: data.start_time,
      end_time: data.end_time,
    };

    const response = await fetch(`/api/appointments/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(appointmentData),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const appointment = await response.json();
    return {
      ...appointment,
      start_time: new Date(appointment.start_time),
      end_time: new Date(appointment.end_time),
      created_at: new Date(appointment.created_at),
      updated_at: new Date(appointment.updated_at),
    };
  } catch (error) {
    console.error('Erro ao atualizar compromisso:', error);
    throw error;
  }
};

export const deleteAppointment = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/appointments/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
  } catch (error) {
    console.error('Erro ao excluir compromisso:', error);
    throw error;
  }
};
