export type Case = {
  id: string;
  case_number: string;
  title: string;
  description: string | null;
  client_id: string | null;
  responsible_lawyer_id: string | null;
  case_type: string;
  status: string;
  priority: string;
  court: string | null;
  case_value: string | null;
  start_date: Date | null;
  expected_end_date: Date | null;
  actual_end_date: Date | null;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
};

export type CaseFormData = {
  case_number: string;
  title: string;
  description: string;
  client_id: string;
  case_type: string;
  status: string;
  priority: string;
  court: string;
  case_value: number;
  start_date: Date;
  expected_end_date?: Date;
};

const convertCase = (caseData: any): Case => ({
  ...caseData,
  start_date: caseData.start_date ? new Date(caseData.start_date) : null,
  expected_end_date: caseData.expected_end_date ? new Date(caseData.expected_end_date) : null,
  actual_end_date: caseData.actual_end_date ? new Date(caseData.actual_end_date) : null,
  created_at: new Date(caseData.created_at),
  updated_at: new Date(caseData.updated_at),
});

export const getCases = async (): Promise<Case[]> => {
  try {
    const response = await fetch('/api/cases');
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const cases = await response.json();
    return cases.map(convertCase);
  } catch (error) {
    console.error('Erro ao buscar casos:', error);
    throw error;
  }
};

export const getCaseById = async (id: string): Promise<Case> => {
  try {
    const response = await fetch(`/api/cases/${id}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const caseData = await response.json();
    return convertCase(caseData);
  } catch (error) {
    console.error('Erro ao buscar caso:', error);
    throw error;
  }
};

export const createCase = async (data: CaseFormData): Promise<Case> => {
  try {
    const response = await fetch('/api/cases', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const caseData = await response.json();
    return convertCase(caseData);
  } catch (error) {
    console.error('Erro ao criar caso:', error);
    throw error;
  }
};

export const updateCase = async (id: string, data: Partial<CaseFormData>): Promise<Case> => {
  try {
    const response = await fetch(`/api/cases/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const caseData = await response.json();
    return convertCase(caseData);
  } catch (error) {
    console.error('Erro ao atualizar caso:', error);
    throw error;
  }
};

export const deleteCase = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/cases/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
  } catch (error) {
    console.error('Erro ao excluir caso:', error);
    throw error;
  }
};