export type Client = {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document_number: string | null;
  client_type: string | null;
  address: string | null;
  notes: string | null;
  status: string;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
};

export type ClientFormData = {
  name: string;
  email: string;
  phone: string;
  document_number: string;
  client_type: "individual" | "company";
  address: string;
  notes: string;
  status: string;
};

const convertClient = (client: any): Client => ({
  ...client,
  created_at: new Date(client.created_at),
  updated_at: new Date(client.updated_at),
});

export const getClients = async (): Promise<Client[]> => {
  try {
    const response = await fetch('/api/clients');
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const clients = await response.json();
    return clients.map(convertClient);
  } catch (error) {
    console.error('Erro ao buscar clientes:', error);
    throw error;
  }
};

export const getClientById = async (id: string): Promise<Client> => {
  try {
    const response = await fetch(`/api/clients/${id}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const client = await response.json();
    return convertClient(client);
  } catch (error) {
    console.error('Erro ao buscar cliente:', error);
    throw error;
  }
};

export const createClient = async (data: ClientFormData): Promise<Client> => {
  try {
    const response = await fetch('/api/clients', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const client = await response.json();
    return convertClient(client);
  } catch (error) {
    console.error('Erro ao criar cliente:', error);
    throw error;
  }
};

export const updateClient = async (id: string, data: Partial<ClientFormData>): Promise<Client> => {
  try {
    const response = await fetch(`/api/clients/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const client = await response.json();
    return convertClient(client);
  } catch (error) {
    console.error('Erro ao atualizar cliente:', error);
    throw error;
  }
};

export const deleteClient = async (id: string): Promise<void> => {
  try {
    const response = await fetch(`/api/clients/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
  } catch (error) {
    console.error('Erro ao excluir cliente:', error);
    throw error;
  }
};