-- Inserir clientes
INSERT INTO clients (name, email, phone, document_number, client_type, address, notes, status, created_by) VALUES 
('Maria Silva Santos', 'maria.santos@email.com', '(11) 99999-9999', '123.456.789-00', 'individual', 'Rua das Flores, 123 - São Paulo/SP', 'Cliente desde 2020', 'active', 'system'),
('João Carlos Oliveira', 'joao.oliveira@email.com', '(11) 88888-8888', '987.654.321-00', 'individual', 'Av. Paulista, 456 - São Paulo/SP', 'Processo trabalhista', 'active', 'system'),
('Empresa XYZ Ltda', 'contato@empresaxyz.com.br', '(11) 77777-7777', '12.345.678/0001-90', 'company', 'Centro Empresarial - São Paulo/SP', 'Consultoria tributária', 'active', 'system'),
('Ana Costa Silva', 'ana.costa@email.com', '(11) 66666-6666', '456.789.123-00', 'individual', 'Rua dos Jardins, 789 - São Paulo/SP', 'Divórcio consensual', 'active', 'system'),
('Tech Solutions Brasil', 'juridico@techsolutions.com.br', '(11) 55555-5555', '98.765.432/0001-10', 'company', 'Vila Olímpia - São Paulo/SP', 'Contratos empresariais', 'active', 'system');

-- Inserir casos
INSERT INTO cases (case_number, title, description, client_id, case_type, status, priority, court, case_value, start_date) VALUES 
('5001234-67.2024.8.26.0001', 'Ação de Divórcio Consensual', 'Processo de divórcio consensual com partilha de bens', (SELECT id FROM clients WHERE name = 'Maria Silva Santos'), 'Direito de Família', 'active', 'high', 'TJSP - 1ª Vara de Família', 150000.00, '2024-01-15'),
('1001567-89.2024.8.26.0100', 'Ação Trabalhista', 'Reclamação trabalhista por verbas rescisórias', (SELECT id FROM clients WHERE name = 'João Carlos Oliveira'), 'Direito Trabalhista', 'active', 'medium', 'TRT - 2ª Região', 75000.00, '2024-02-03'),
('2001890-12.2024.8.26.0224', 'Consultoria Tributária ICMS', 'Assessoria em questões tributárias relacionadas ao ICMS', (SELECT id FROM clients WHERE name = 'Empresa XYZ Ltda'), 'Direito Tributário', 'active', 'high', 'TJSP - Vara da Fazenda Pública', 500000.00, '2024-03-10'),
('3001234-45.2024.8.26.0001', 'Divórcio Litigioso', 'Processo de divórcio com disputa de guarda', (SELECT id FROM clients WHERE name = 'Ana Costa Silva'), 'Direito de Família', 'active', 'medium', 'TJSP - 2ª Vara de Família', 200000.00, '2024-04-20'),
('4001567-78.2024.8.26.0100', 'Revisão Contratual', 'Revisão de contratos empresariais e consultoria jurídica', (SELECT id FROM clients WHERE name = 'Tech Solutions Brasil'), 'Direito Empresarial', 'active', 'low', 'Câmara de Arbitragem', 300000.00, '2024-05-15');

-- Inserir compromissos
INSERT INTO appointments (title, description, appointment_type, start_time, end_time, location, case_id, client_id, assigned_to, is_confirmed, created_by) VALUES 
('Audiência de Conciliação', 'Tentativa de acordo no processo de divórcio', 'hearing', '2024-11-15 14:00:00', '2024-11-15 16:00:00', 'Fórum Central - Sala 205', (SELECT id FROM cases WHERE case_number = '5001234-67.2024.8.26.0001'), (SELECT id FROM clients WHERE name = 'Maria Silva Santos'), 'Dr. Vitor Dias', true, 'system'),
('Reunião com Cliente', 'Discussão sobre estratégia processual', 'meeting', '2024-11-12 10:00:00', '2024-11-12 11:30:00', 'Escritório - Sala de Reuniões', (SELECT id FROM cases WHERE case_number = '1001567-89.2024.8.26.0100'), (SELECT id FROM clients WHERE name = 'João Carlos Oliveira'), 'Dra. Ana Costa', false, 'system'),
('Prazo Processual', 'Vencimento para apresentação de defesa', 'deadline', '2024-11-20 17:00:00', '2024-11-20 17:00:00', 'Protocolo Judicial', (SELECT id FROM cases WHERE case_number = '2001890-12.2024.8.26.0224'), (SELECT id FROM clients WHERE name = 'Empresa XYZ Ltda'), 'Dr. Roberto Silva', true, 'system'),
('Consulta Jurídica', 'Orientação sobre direitos na separação', 'consultation', '2024-11-18 15:00:00', '2024-11-18 16:00:00', 'Escritório - Sala 3', (SELECT id FROM cases WHERE case_number = '3001234-45.2024.8.26.0001'), (SELECT id FROM clients WHERE name = 'Ana Costa Silva'), 'Dr. Vitor Dias', true, 'system'),
('Reunião Empresarial', 'Análise de contratos comerciais', 'meeting', '2024-11-25 09:00:00', '2024-11-25 12:00:00', 'Sede da Empresa', (SELECT id FROM cases WHERE case_number = '4001567-78.2024.8.26.0100'), (SELECT id FROM clients WHERE name = 'Tech Solutions Brasil'), 'Dra. Ana Costa', false, 'system');
